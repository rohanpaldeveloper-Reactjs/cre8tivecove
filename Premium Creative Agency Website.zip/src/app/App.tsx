import { useState, useEffect, useRef, useCallback } from "react";
import {
  Play, ArrowRight, Menu, X, ArrowUpRight, MapPin, Phone, Mail,
  Instagram, Linkedin, Twitter, Youtube, Film, Monitor, Palette,
  Camera, Globe, Layers, Star, Check, ChevronRight, Plus, Minus,
  Award, Users, Eye, Zap, Clock, Target, TrendingUp
} from "lucide-react";

// ─── Scroll reveal ────────────────────────────────────────────────────────────
function useReveal(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, visible };
}

function Reveal({
  children, delay = 0, className = "", from = "bottom"
}: {
  children: React.ReactNode; delay?: number; className?: string; from?: "bottom" | "left" | "right" | "none";
}) {
  const { ref, visible } = useReveal();
  const transforms: Record<string, string> = {
    bottom: "translateY(40px)", left: "translateX(-40px)", right: "translateX(40px)", none: "none"
  };
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "none" : transforms[from],
        transition: `opacity 0.8s cubic-bezier(0.16,1,0.3,1) ${delay}s, transform 0.8s cubic-bezier(0.16,1,0.3,1) ${delay}s`,
        willChange: "opacity, transform",
      }}
    >
      {children}
    </div>
  );
}

// ─── Nav ──────────────────────────────────────────────────────────────────────
const NAV_ITEMS = [
  { label: "Work", page: "Work" },
  { label: "Services", page: "Services" },
  { label: "About", page: "About" },
  { label: "Careers", page: "Careers" },
  { label: "Contact", page: "Contact" },
];

function Nav({ page, setPage }: { page: string; setPage: (p: string) => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const go = (p: string) => { setPage(p); setMenuOpen(false); };

  return (
    <>
      <header
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-700"
        style={{
          background: scrolled ? "rgba(255,255,255,0.94)" : "transparent",
          backdropFilter: scrolled ? "saturate(180%) blur(24px)" : "none",
          borderBottom: scrolled ? "1px solid rgba(0,0,0,0.055)" : "none",
        }}
      >
        <div className="max-w-[1440px] mx-auto px-6 lg:px-14 flex items-center justify-between h-[68px] lg:h-[76px]">
          {/* Logo */}
          <button onClick={() => go("Home")} className="flex items-center gap-2.5 group">
            <div
              className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 transition-transform duration-300 group-hover:scale-110"
              style={{ background: "linear-gradient(135deg, #C8A96B, #b8924f)" }}
            >
              <Film size={13} className="text-white" />
            </div>
            <span style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: "1.05rem", color: "#111", letterSpacing: "-0.01em" }}>
              Lumière
            </span>
          </button>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {NAV_ITEMS.map(({ label, page: p }) => (
              <button
                key={label}
                onClick={() => go(p)}
                className="px-4 py-2 rounded-lg text-sm transition-all duration-200 relative"
                style={{
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  fontWeight: page === p ? 600 : 500,
                  color: page === p ? "#C8A96B" : "#444",
                  background: page === p ? "rgba(200,169,107,0.08)" : "transparent",
                }}
              >
                {label}
              </button>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-3">
            <button
              onClick={() => go("Contact")}
              className="group flex items-center gap-2 px-5 py-2.5 rounded-full text-[13px] font-semibold transition-all duration-300 hover:shadow-lg hover:shadow-black/10 hover:-translate-y-px"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", background: "#111", color: "#fff" }}
            >
              Start a Project
              <ArrowRight size={13} className="transition-transform duration-200 group-hover:translate-x-0.5" />
            </button>
          </div>

          <button onClick={() => setMenuOpen(!menuOpen)} className="lg:hidden p-2 -mr-2">
            {menuOpen ? <X size={20} color="#111" /> : <Menu size={20} color="#111" />}
          </button>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        className="fixed inset-0 z-40 lg:hidden transition-all duration-400"
        style={{
          opacity: menuOpen ? 1 : 0,
          pointerEvents: menuOpen ? "all" : "none",
          background: "rgba(255,255,255,0.97)",
          backdropFilter: "blur(20px)",
          paddingTop: 80,
        }}
      >
        <nav className="flex flex-col px-8 gap-1">
          {NAV_ITEMS.map(({ label, page: p }) => (
            <button
              key={label}
              onClick={() => go(p)}
              className="text-left py-4 text-2xl font-semibold border-b border-gray-100 transition-colors"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: page === p ? "#C8A96B" : "#111",
                fontStyle: page === p ? "italic" : "normal",
              }}
            >
              {label}
            </button>
          ))}
          <button
            onClick={() => go("Contact")}
            className="mt-6 py-4 rounded-2xl text-base font-semibold text-center"
            style={{ background: "#111", color: "#fff", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          >
            Start a Project
          </button>
        </nav>
      </div>
    </>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer({ setPage }: { setPage: (p: string) => void }) {
  const go = (p: string) => { setPage(p); window.scrollTo({ top: 0 }); };
  return (
    <footer style={{ background: "#0D0D0D" }}>
      <div className="max-w-[1440px] mx-auto px-6 lg:px-14 pt-20 pb-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-16 border-b border-white/[0.06]">
          <div className="lg:col-span-5">
            <button onClick={() => go("Home")} className="flex items-center gap-2.5 mb-7">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "linear-gradient(135deg, #C8A96B, #b8924f)" }}>
                <Film size={14} className="text-white" />
              </div>
              <span style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: "1.15rem", color: "#fff" }}>Lumière</span>
            </button>
            <p className="text-sm leading-relaxed max-w-xs" style={{ fontFamily: "'Inter', sans-serif", color: "rgba(255,255,255,0.38)" }}>
              A premium creative studio specializing in film, brand identity, and digital experiences for ambitious brands worldwide.
            </p>
            <div className="flex gap-3 mt-8">
              {[Instagram, Linkedin, Twitter, Youtube].map((Icon, i) => (
                <a
                  key={i} href="#"
                  className="w-9 h-9 rounded-full border flex items-center justify-center transition-all duration-200 hover:border-[#C8A96B] hover:bg-[#C8A96B15]"
                  style={{ borderColor: "rgba(255,255,255,0.1)" }}
                >
                  <Icon size={14} style={{ color: "rgba(255,255,255,0.45)" }} />
                </a>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 lg:col-start-7">
            <p className="text-[10px] font-bold uppercase tracking-[0.15em] mb-5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "rgba(255,255,255,0.25)" }}>Pages</p>
            <div className="flex flex-col gap-3">
              {["Home", "Work", "Services", "About", "Careers", "Contact"].map((l) => (
                <button key={l} onClick={() => go(l)} className="text-left text-[13px] transition-colors hover:text-white" style={{ fontFamily: "'Inter', sans-serif", color: "rgba(255,255,255,0.45)" }}>{l}</button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3 lg:col-start-10">
            <p className="text-[10px] font-bold uppercase tracking-[0.15em] mb-5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "rgba(255,255,255,0.25)" }}>Contact</p>
            <div className="flex flex-col gap-4">
              {[
                { Icon: Mail, text: "hello@lumierestudio.co" },
                { Icon: Phone, text: "+1 (310) 555-0192" },
                { Icon: MapPin, text: "Sunset Blvd, Los Angeles" },
              ].map(({ Icon, text }) => (
                <div key={text} className="flex items-center gap-3">
                  <Icon size={13} style={{ color: "#C8A96B" }} />
                  <span className="text-[13px]" style={{ fontFamily: "'Inter', sans-serif", color: "rgba(255,255,255,0.45)" }}>{text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <p className="text-[11px]" style={{ fontFamily: "'Inter', sans-serif", color: "rgba(255,255,255,0.2)" }}>© 2024 Lumière Studio. All rights reserved.</p>
          <p className="text-[11px]" style={{ fontFamily: "'Inter', sans-serif", color: "rgba(255,255,255,0.15)" }}>Made in Los Angeles · Est. 2016</p>
        </div>
      </div>
    </footer>
  );
}

// ─── HOME ─────────────────────────────────────────────────────────────────────
const FEATURED_WORK = [
  { title: "Horizon Corporate Film", cat: "Corporate Film", client: "Horizon Group", img: "1574717024653-61fd2cf4d44d", span: 7, tall: false },
  { title: "Vetro Brand Campaign", cat: "Commercial", client: "Vetro Wellness", img: "1485846234645-a62644f84728", span: 5, tall: true },
  { title: "Strata Product Launch", cat: "Product Video", client: "Strata Tech", img: "1561070791-2526d30994b5", span: 5, tall: true },
  { title: "Meridian Identity", cat: "Branding", client: "Meridian Co.", img: "1558618666-fcd25c85cd64", span: 7, tall: false },
];

const HOME_SERVICES = [
  { Icon: Film, title: "Video Production", desc: "Cinematic brand films & documentaries" },
  { Icon: Camera, title: "Commercial Shoots", desc: "TV, digital & social campaigns" },
  { Icon: Globe, title: "Web Development", desc: "Custom performant web experiences" },
  { Icon: Monitor, title: "UI/UX Design", desc: "Research-driven digital products" },
  { Icon: Palette, title: "Graphic Design", desc: "Print, packaging & digital assets" },
  { Icon: Layers, title: "Brand Identity", desc: "Strategy, naming & visual systems" },
];

const TESTIMONIALS = [
  {
    quote: "Lumière didn't just produce a film — they amplified our vision into something we hadn't imagined was possible.",
    name: "Marcus Chen", role: "CMO, Horizon Group", avatar: "1507003211169-0a1dd7228f2d", rating: 5,
  },
  {
    quote: "Our brand identity conversion rate jumped 40% in Q1. The work speaks entirely for itself.",
    name: "Sofia Andersen", role: "Founder, Vetro Wellness", avatar: "1494790108377-be9c29b29330", rating: 5,
  },
  {
    quote: "Working with Lumière felt like working with a team that cared as much about the outcome as we did. Rare.",
    name: "David Okafor", role: "VP Marketing, Pinnacle Tech", avatar: "1472099645785-5658abf4ff4e", rating: 5,
  },
];

function HomePage({ setPage }: { setPage: (p: string) => void }) {
  const [heroLoaded, setHeroLoaded] = useState(false);
  const [hoveredWork, setHoveredWork] = useState<number | null>(null);
  const [hoveredService, setHoveredService] = useState<number | null>(null);
  const [activeStep, setActiveStep] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setHeroLoaded(true), 100);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => setActiveStep(s => (s + 1) % 5), 2200);
    return () => clearInterval(interval);
  }, []);

  const go = (p: string) => { setPage(p); window.scrollTo({ top: 0 }); };

  return (
    <div>
      {/* ── HERO ── */}
      <section className="min-h-screen grid grid-cols-1 lg:grid-cols-2 overflow-hidden">
        {/* Left panel */}
        <div className="flex flex-col justify-center px-6 lg:pl-14 lg:pr-12 pt-28 pb-16 lg:pt-0 lg:pb-0 relative">
          <div
            style={{
              opacity: heroLoaded ? 1 : 0,
              transform: heroLoaded ? "none" : "translateY(24px)",
              transition: "opacity 1s ease 0.2s, transform 1s ease 0.2s",
            }}
          >
            <div className="flex items-center gap-2.5 mb-10">
              <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: "#C8A96B" }} />
              <span className="text-[11px] font-semibold uppercase tracking-[0.18em]" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>
                Award-Winning Creative Studio
              </span>
            </div>
            <h1
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(3.2rem, 5.5vw, 5.8rem)",
                fontWeight: 900,
                lineHeight: 1.03,
                color: "#111",
                letterSpacing: "-0.025em",
              }}
            >
              We Create<br />
              <em style={{ fontStyle: "italic", color: "#C8A96B" }}>Stories</em> That<br />
              Move Brands.
            </h1>
            <p
              className="mt-8 text-lg max-w-[420px] leading-[1.75]"
              style={{ fontFamily: "'Inter', sans-serif", color: "#888", fontWeight: 400 }}
            >
              Corporate Films, Commercial Videos, Websites & Creative Experiences — crafted for brands that demand excellence.
            </p>
            <div className="flex flex-wrap gap-4 mt-10">
              <button
                onClick={() => go("Work")}
                className="group flex items-center gap-2.5 px-7 py-3.5 rounded-full text-[13px] font-semibold transition-all duration-300 hover:shadow-2xl hover:shadow-black/15 hover:-translate-y-0.5"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", background: "#111", color: "#fff" }}
              >
                View Our Work
                <ArrowRight size={14} className="transition-transform duration-200 group-hover:translate-x-0.5" />
              </button>
              <button
                onClick={() => go("Contact")}
                className="group flex items-center gap-2 px-7 py-3.5 rounded-full text-[13px] font-semibold border transition-all duration-300 hover:-translate-y-0.5 hover:border-[#C8A96B] hover:text-[#C8A96B]"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", borderColor: "#E0E0E0", color: "#444" }}
              >
                Book a Discovery Call
              </button>
            </div>
          </div>

          {/* Bottom stats strip */}
          <div
            className="absolute bottom-0 left-0 right-0 lg:right-auto lg:left-14 lg:w-[calc(100%-3.5rem)] flex gap-8 pb-10"
            style={{ opacity: heroLoaded ? 1 : 0, transition: "opacity 1s ease 0.8s" }}
          >
            {[["500+", "Projects"], ["100+", "Clients"], ["8+", "Years"]].map(([val, lbl]) => (
              <div key={lbl}>
                <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 900, fontSize: "1.5rem", color: "#111" }}>{val}</div>
                <div style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.7rem", color: "#aaa", marginTop: 1 }}>{lbl}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right panel */}
        <div className="relative min-h-[56vw] lg:min-h-0" style={{ background: "#111" }}>
          <img
            src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=1100&h=900&fit=crop&auto=format"
            alt="Cinematic production"
            className="absolute inset-0 w-full h-full object-cover"
            style={{ opacity: 0.72 }}
          />
          {/* Diagonal clip on left edge */}
          <div
            className="absolute inset-y-0 left-0 w-20 hidden lg:block"
            style={{ background: "linear-gradient(to right, #fff, transparent)" }}
          />

          {/* Play button overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            <button
              className="group flex flex-col items-center gap-3 transition-all duration-300 hover:scale-105"
              style={{
                opacity: heroLoaded ? 1 : 0,
                transition: "opacity 1s ease 1s, transform 0.3s ease",
              }}
            >
              <div
                className="w-20 h-20 rounded-full flex items-center justify-center"
                style={{ background: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.25)", backdropFilter: "blur(12px)" }}
              >
                <Play size={24} fill="white" className="text-white" style={{ marginLeft: 3 }} />
              </div>
              <span className="text-[11px] font-semibold uppercase tracking-widest text-white/60" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                Watch Showreel
              </span>
            </button>
          </div>

          {/* Floating stat cards */}
          <div
            className="absolute top-8 right-8 flex flex-col gap-3"
            style={{ opacity: heroLoaded ? 1 : 0, transition: "opacity 1s ease 1.2s" }}
          >
            {[["500+", "Projects Delivered"], ["3M+", "Total Views"], ["100+", "Happy Clients"]].map(([v, l]) => (
              <div
                key={l}
                className="flex items-center gap-3 px-4 py-3 rounded-2xl"
                style={{ background: "rgba(255,255,255,0.08)", backdropFilter: "blur(20px)", border: "1px solid rgba(255,255,255,0.12)" }}
              >
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: "#C8A96B" }} />
                <div>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 900, fontSize: "1.1rem", color: "#fff" }}>{v}</div>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.65rem", color: "rgba(255,255,255,0.5)" }}>{l}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── MARQUEE ── */}
      <div className="py-6 overflow-hidden border-y" style={{ borderColor: "rgba(0,0,0,0.06)" }}>
        <div
          className="flex gap-16 whitespace-nowrap"
          style={{
            animation: "marquee 30s linear infinite",
            width: "max-content",
          }}
        >
          {[...Array(3)].flatMap(() =>
            ["Corporate Films", "Commercial Production", "Brand Identity", "Website Development", "UI/UX Design", "Product Videos", "Drone Cinematography", "Motion Graphics"].map((t, i) => (
              <span key={`${t}-${i}`} className="inline-flex items-center gap-4 text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#aaa" }}>
                <span className="w-1 h-1 rounded-full inline-block" style={{ background: "#C8A96B" }} />
                {t}
              </span>
            ))
          )}
        </div>
        <style>{`@keyframes marquee { from { transform: translateX(0) } to { transform: translateX(-33.33%) } }`}</style>
      </div>

      {/* ── FEATURED WORK ── */}
      <section className="py-32 px-6 lg:px-14 max-w-[1440px] mx-auto">
        <div className="flex items-end justify-between mb-16">
          <Reveal>
            <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Selected Work</p>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.4rem, 4vw, 3.75rem)", fontWeight: 900, color: "#111", lineHeight: 1.08, letterSpacing: "-0.02em" }}>
              Projects that define<br /><em style={{ fontStyle: "italic" }}>categories.</em>
            </h2>
          </Reveal>
          <Reveal from="right">
            <button
              onClick={() => go("Work")}
              className="hidden lg:flex items-center gap-2 text-[13px] font-semibold group transition-all duration-200"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}
            >
              All Projects <ArrowUpRight size={14} className="transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </Reveal>
        </div>

        {/* Work grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {FEATURED_WORK.map((item, i) => (
            <Reveal
              key={i}
              delay={i * 0.1}
              className="contents"
            >
              <div
                className={`lg:col-span-${item.span} relative overflow-hidden rounded-2xl cursor-pointer group`}
                style={{
                  height: item.tall ? 520 : 420,
                  background: "#F3F3F3",
                  gridColumn: `span ${item.span}`,
                  opacity: 0,
                  transform: "translateY(40px)",
                  animation: `none`,
                }}
                ref={(el) => {
                  if (!el) return;
                  const obs = new IntersectionObserver(([e]) => {
                    if (e.isIntersecting) {
                      el.style.transition = `opacity 0.8s cubic-bezier(0.16,1,0.3,1) ${i * 0.1}s, transform 0.8s cubic-bezier(0.16,1,0.3,1) ${i * 0.1}s`;
                      el.style.opacity = "1";
                      el.style.transform = "none";
                      obs.disconnect();
                    }
                  }, { threshold: 0.08 });
                  obs.observe(el);
                }}
                onMouseEnter={() => setHoveredWork(i)}
                onMouseLeave={() => setHoveredWork(null)}
              >
                <img
                  src={`https://images.unsplash.com/photo-${item.img}?w=900&h=700&fit=crop&auto=format`}
                  alt={item.title}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out"
                  style={{ transform: hoveredWork === i ? "scale(1.06)" : "scale(1)" }}
                />
                <div
                  className="absolute inset-0 transition-opacity duration-500"
                  style={{ background: "linear-gradient(to top, rgba(0,0,0,0.82) 0%, transparent 55%)", opacity: hoveredWork === i ? 1 : 0.55 }}
                />

                {/* Hover badge */}
                <div
                  className="absolute top-5 right-5 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-400"
                  style={{
                    background: "rgba(255,255,255,0.12)",
                    backdropFilter: "blur(12px)",
                    border: "1px solid rgba(255,255,255,0.2)",
                    opacity: hoveredWork === i ? 1 : 0,
                    transform: hoveredWork === i ? "scale(1)" : "scale(0.8)",
                  }}
                >
                  <ArrowUpRight size={16} className="text-white" />
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-7">
                  <span className="text-[10px] font-bold uppercase tracking-[0.15em]" style={{ color: "#C8A96B", fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{item.cat}</span>
                  <h3 className="mt-1.5 text-xl font-bold text-white leading-snug" style={{ fontFamily: "'Playfair Display', serif" }}>{item.title}</h3>
                  <p
                    className="text-[12px] text-white/50 mt-2 transition-all duration-300"
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      opacity: hoveredWork === i ? 1 : 0,
                      transform: hoveredWork === i ? "translateY(0)" : "translateY(6px)",
                    }}
                  >
                    {item.client}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── SERVICES ── */}
      <section style={{ background: "#F7F7F7" }} className="py-32 px-6 lg:px-14">
        <div className="max-w-[1440px] mx-auto">
          <div className="flex flex-col lg:flex-row lg:items-end gap-8 lg:gap-20 mb-16">
            <Reveal className="flex-1">
              <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>What We Do</p>
              <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.4rem, 4vw, 3.75rem)", fontWeight: 900, color: "#111", lineHeight: 1.08, letterSpacing: "-0.02em" }}>
                Full-spectrum<br /><em style={{ fontStyle: "italic" }}>creative services.</em>
              </h2>
            </Reveal>
            <Reveal delay={0.1} className="max-w-sm">
              <p className="text-sm leading-relaxed" style={{ fontFamily: "'Inter', sans-serif", color: "#888" }}>
                From a single hero film to a complete brand ecosystem — every engagement receives the same obsessive level of craft.
              </p>
            </Reveal>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {HOME_SERVICES.map((s, i) => (
              <Reveal key={i} delay={i * 0.07}>
                <div
                  className="group bg-white rounded-2xl p-8 cursor-pointer transition-all duration-400 hover:-translate-y-1"
                  style={{
                    boxShadow: hoveredService === i ? "0 24px 64px rgba(0,0,0,0.1)" : "0 1px 12px rgba(0,0,0,0.05)",
                  }}
                  onMouseEnter={() => setHoveredService(i)}
                  onMouseLeave={() => setHoveredService(null)}
                >
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center mb-6 transition-all duration-300"
                    style={{ background: hoveredService === i ? "#C8A96B" : "rgba(200,169,107,0.1)" }}
                  >
                    <s.Icon size={18} style={{ color: hoveredService === i ? "#fff" : "#C8A96B" }} />
                  </div>
                  <h3 className="text-base font-bold mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{s.title}</h3>
                  <p className="text-sm" style={{ fontFamily: "'Inter', sans-serif", color: "#888", lineHeight: 1.6 }}>{s.desc}</p>
                  <div
                    className="flex items-center gap-1.5 mt-6 transition-all duration-200"
                    style={{ color: "#C8A96B" }}
                  >
                    <span className="text-[12px] font-semibold" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Learn more</span>
                    <ArrowRight size={11} />
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── PROCESS + STATS ── */}
      <section className="py-32 px-6 lg:px-14 max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
          {/* Process */}
          <div>
            <Reveal>
              <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>How We Work</p>
              <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2rem, 3.5vw, 3rem)", fontWeight: 900, color: "#111", lineHeight: 1.1, letterSpacing: "-0.02em" }} className="mb-12">
                Strategy to screen —<br /><em style={{ fontStyle: "italic" }}>every step.</em>
              </h2>
            </Reveal>
            {["Strategy", "Concept", "Production", "Post Production", "Launch"].map((step, i) => (
              <Reveal key={i} delay={i * 0.1}>
                <div
                  className="flex gap-5 pb-8 relative cursor-pointer group transition-all duration-300"
                  onClick={() => setActiveStep(i)}
                >
                  {i < 4 && <div className="absolute left-5 top-10 bottom-0 w-px" style={{ background: activeStep >= i ? "#C8A96B" : "#E8E8E8", transition: "background 0.5s" }} />}
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 z-10 text-[11px] font-bold transition-all duration-300"
                    style={{
                      background: activeStep === i ? "#C8A96B" : activeStep > i ? "#111" : "#F7F7F7",
                      color: activeStep >= i ? "#fff" : "#aaa",
                      fontFamily: "'Plus Jakarta Sans', sans-serif",
                      border: activeStep === i ? "2px solid #C8A96B" : "none",
                    }}
                  >
                    {activeStep > i ? <Check size={14} /> : String(i + 1).padStart(2, "0")}
                  </div>
                  <div className="pt-2">
                    <h4 className="font-bold text-sm transition-colors duration-200" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: activeStep === i ? "#111" : "#aaa" }}>{step}</h4>
                    <p
                      className="text-[13px] mt-1 leading-relaxed overflow-hidden transition-all duration-400"
                      style={{
                        fontFamily: "'Inter', sans-serif",
                        color: "#888",
                        maxHeight: activeStep === i ? "60px" : "0",
                        opacity: activeStep === i ? 1 : 0,
                      }}
                    >
                      {["Audience mapping, competitive analysis, and creative brief.", "Moodboards, storyboards, and creative concept development.", "On-location or studio capture with cinema-grade equipment.", "Color grade, sound design, edit, and motion graphics.", "Delivery across every platform with performance tracking."][i]}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          {/* Stats & image */}
          <div>
            <Reveal delay={0.2}>
              <div className="relative rounded-2xl overflow-hidden mb-5" style={{ height: 380, background: "#F7F7F7" }}>
                <img
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=900&h=600&fit=crop&auto=format"
                  alt="Our team at work"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.5) 0%, transparent 50%)" }} />
                <div className="absolute bottom-6 left-6">
                  <span className="text-[11px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-full" style={{ background: "#C8A96B", color: "#fff", fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    8 Years of Craft
                  </span>
                </div>
              </div>
            </Reveal>
            <div className="grid grid-cols-3 gap-4">
              {[["500+", "Projects"], ["3M+", "Views"], ["100+", "Clients"]].map(([v, l]) => (
                <Reveal key={l} delay={0.3}>
                  <div className="rounded-2xl p-6 text-center" style={{ background: "#F7F7F7" }}>
                    <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.75rem", fontWeight: 900, color: "#111" }}>{v}</div>
                    <div style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.7rem", color: "#aaa", marginTop: 3 }}>{l}</div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section style={{ background: "#F7F7F7" }} className="py-32 px-6 lg:px-14">
        <div className="max-w-[1440px] mx-auto">
          <Reveal className="text-center mb-16">
            <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Client Stories</p>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.4rem, 4vw, 3.75rem)", fontWeight: 900, color: "#111", lineHeight: 1.08, letterSpacing: "-0.02em" }}>
              What our clients say.
            </h2>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {TESTIMONIALS.map((t, i) => (
              <Reveal key={i} delay={i * 0.12}>
                <div className="bg-white rounded-2xl p-8 flex flex-col" style={{ boxShadow: "0 2px 24px rgba(0,0,0,0.055)" }}>
                  <div className="flex gap-0.5 mb-5">
                    {[...Array(t.rating)].map((_, j) => <Star key={j} size={12} fill="#C8A96B" style={{ color: "#C8A96B" }} />)}
                  </div>
                  <blockquote
                    className="text-sm leading-[1.8] flex-1"
                    style={{ fontFamily: "'Inter', sans-serif", color: "#555", fontStyle: "italic" }}
                  >
                    &ldquo;{t.quote}&rdquo;
                  </blockquote>
                  <div className="flex items-center gap-3 mt-7 pt-6 border-t border-gray-100">
                    <img
                      src={`https://images.unsplash.com/photo-${t.avatar}?w=80&h=80&fit=crop&auto=format`}
                      alt={t.name}
                      className="w-10 h-10 rounded-full object-cover bg-gray-200 flex-shrink-0"
                    />
                    <div>
                      <p className="text-[13px] font-semibold" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{t.name}</p>
                      <p className="text-[11px] mt-0.5" style={{ fontFamily: "'Inter', sans-serif", color: "#bbb" }}>{t.role}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── BEHIND THE SCENES ── */}
      <section className="py-32 px-6 lg:px-14 max-w-[1440px] mx-auto">
        <Reveal>
          <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Behind the Lens</p>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.4rem, 4vw, 3.75rem)", fontWeight: 900, color: "#111", lineHeight: 1.08, letterSpacing: "-0.02em" }} className="mb-16">
            Where the magic<br /><em style={{ fontStyle: "italic" }}>happens.</em>
          </h2>
        </Reveal>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 items-start">
          {[
            { img: "1485846234645-a62644f84728", label: "Camera Ops", h: 300, mt: 0 },
            { img: "1508739773434-c26b3d09e071", label: "Drone Shoots", h: 380, mt: 48 },
            { img: "1574717024653-61fd2cf4d44d", label: "Cinematography", h: 380, mt: 0 },
            { img: "1531403236541-e5f16c22a4c3", label: "Editing Suite", h: 300, mt: 48 },
          ].map((item, i) => (
            <Reveal key={i} delay={i * 0.1}>
              <div
                className="relative overflow-hidden rounded-2xl group cursor-pointer"
                style={{ height: item.h, marginTop: item.mt, background: "#F3F3F3" }}
              >
                <img
                  src={`https://images.unsplash.com/photo-${item.img}?w=500&h=600&fit=crop&auto=format`}
                  alt={item.label}
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 transition-opacity duration-300 opacity-0 group-hover:opacity-100" style={{ background: "rgba(0,0,0,0.38)" }} />
                <div
                  className="absolute bottom-5 left-5 transition-all duration-300 opacity-0 group-hover:opacity-100"
                  style={{ transform: "translateY(4px)" }}
                >
                  <span className="text-xs font-semibold text-white" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{item.label}</span>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="mx-4 lg:mx-14 mb-24">
        <div
          className="relative overflow-hidden rounded-3xl px-8 lg:px-20 py-24 text-center"
          style={{ background: "#111" }}
        >
          <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse at 60% 40%, rgba(200,169,107,0.14) 0%, transparent 65%)" }} />
          <Reveal>
            <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-6" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Let&apos;s Begin</p>
            <h2
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(2.5rem, 5vw, 4.5rem)",
                fontWeight: 900,
                color: "#fff",
                lineHeight: 1.07,
                letterSpacing: "-0.02em",
              }}
              className="mb-10"
            >
              Ready to create<br /><em style={{ fontStyle: "italic", color: "#C8A96B" }}>something remarkable?</em>
            </h2>
            <button
              onClick={() => go("Contact")}
              className="group inline-flex items-center gap-2.5 px-8 py-4 rounded-full text-[13px] font-semibold transition-all duration-300 hover:scale-105 hover:shadow-2xl"
              style={{ background: "#C8A96B", color: "#fff", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Let&apos;s Talk
              <ArrowRight size={14} className="transition-transform duration-200 group-hover:translate-x-0.5" />
            </button>
          </Reveal>
        </div>
      </section>
    </div>
  );
}

// ─── ABOUT ────────────────────────────────────────────────────────────────────
function AboutPage({ setPage }: { setPage: (p: string) => void }) {
  return (
    <div className="pt-[76px]">
      {/* Hero */}
      <section className="relative min-h-[80vh] flex items-end overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1800&h=900&fit=crop&auto=format"
          alt="Lumière team"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.15) 50%, transparent 100%)" }} />
        <div className="relative z-10 px-6 lg:px-14 pb-24 max-w-[1440px] mx-auto w-full">
          <Reveal>
            <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>About Us</p>
            <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(3rem, 6vw, 5.5rem)", fontWeight: 900, color: "#fff", lineHeight: 1.04, letterSpacing: "-0.025em", maxWidth: "800px" }}>
              Filmmakers, Designers<br />&amp; <em style={{ fontStyle: "italic" }}>Digital Creators.</em>
            </h1>
          </Reveal>
        </div>
      </section>

      {/* Story */}
      <section className="py-32 px-6 lg:px-14 max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-5">
            <Reveal>
              <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Our Story</p>
              <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2rem, 3.5vw, 3rem)", fontWeight: 900, color: "#111", lineHeight: 1.1, letterSpacing: "-0.02em" }}>
                Born from a love<br />of <em style={{ fontStyle: "italic" }}>storytelling.</em>
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            <Reveal delay={0.15}>
              <p className="text-[15px] leading-[1.9] mb-6" style={{ fontFamily: "'Inter', sans-serif", color: "#666" }}>
                Founded in 2016 in Los Angeles, Lumière Studio began as a two-person team with a single camera and an outsized belief: every brand has a story worth telling beautifully. Over eight years, we&apos;ve grown into a full-spectrum creative studio of 24 specialists across film, design, and digital.
              </p>
              <p className="text-[15px] leading-[1.9]" style={{ fontFamily: "'Inter', sans-serif", color: "#666" }}>
                We&apos;ve partnered with Fortune 500 corporations, funded startups, luxury hospitality brands, and nonprofits. The obsessive attention to craft that earned us our reputation has never changed.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Mission / Vision */}
      <section style={{ background: "#F7F7F7" }} className="py-20 px-6 lg:px-14">
        <div className="max-w-[1440px] mx-auto grid grid-cols-1 md:grid-cols-2 gap-5">
          {[
            { label: "Mission", icon: Target, text: "To translate every brand's truest vision into cinematic, strategic creative work that connects and converts — regardless of scale or industry." },
            { label: "Vision", icon: Eye, text: "A world where every ambitious brand has access to world-class creative production and storytelling that shifts culture." },
          ].map(({ label, icon: Icon, text }) => (
            <Reveal key={label}>
              <div className="bg-white rounded-2xl p-10" style={{ boxShadow: "0 2px 24px rgba(0,0,0,0.05)" }}>
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(200,169,107,0.1)" }}>
                    <Icon size={18} style={{ color: "#C8A96B" }} />
                  </div>
                  <span className="text-[11px] font-bold uppercase tracking-[0.15em]" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>{label}</span>
                </div>
                <p className="text-[15px] leading-[1.85]" style={{ fontFamily: "'Inter', sans-serif", color: "#666" }}>{text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Team */}
      <section className="py-32 px-6 lg:px-14 max-w-[1440px] mx-auto">
        <Reveal>
          <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>The Team</p>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2rem, 3.5vw, 3rem)", fontWeight: 900, color: "#111", lineHeight: 1.1, letterSpacing: "-0.02em" }} className="mb-16">
            The people behind<br /><em style={{ fontStyle: "italic" }}>the work.</em>
          </h2>
        </Reveal>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
          {[
            { name: "Elias Varda", role: "Creative Director", img: "1472099645785-5658abf4ff4e" },
            { name: "Nadia Osei", role: "Head of Production", img: "1494790108377-be9c29b29330" },
            { name: "Tomás Reyes", role: "Lead Cinematographer", img: "1507003211169-0a1dd7228f2d" },
            { name: "Lena Hoffmann", role: "Brand Strategy", img: "1438761681033-6461ffad8d80" },
          ].map((m, i) => (
            <Reveal key={i} delay={i * 0.09}>
              <div className="group cursor-pointer">
                <div className="relative overflow-hidden rounded-2xl mb-4" style={{ height: 300, background: "#F7F7F7" }}>
                  <img
                    src={`https://images.unsplash.com/photo-${m.img}?w=500&h=600&fit=crop&auto=format`}
                    alt={m.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-104"
                  />
                  <div className="absolute inset-0 transition-opacity duration-300 opacity-0 group-hover:opacity-100" style={{ background: "rgba(200,169,107,0.12)" }} />
                </div>
                <h4 className="font-semibold text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{m.name}</h4>
                <p className="text-[12px] mt-0.5" style={{ fontFamily: "'Inter', sans-serif", color: "#aaa" }}>{m.role}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Awards */}
      <section style={{ background: "#0D0D0D" }} className="py-20 px-6 lg:px-14">
        <div className="max-w-[1440px] mx-auto">
          <Reveal className="text-center mb-14">
            <p className="text-[11px] font-bold uppercase tracking-[0.15em]" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Recognition</p>
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { award: "Awwwards", detail: "SOTD × 12" },
              { award: "Cannes Lions", detail: "Gold 2023" },
              { award: "Webby Awards", detail: "Best Video" },
              { award: "D&AD", detail: "Wood Pencil" },
            ].map(({ award, detail }) => (
              <Reveal key={award}>
                <div className="text-center py-8 px-4 rounded-2xl border border-white/[0.07] hover:border-[#C8A96B44] transition-colors duration-300 group">
                  <Award size={20} className="mx-auto mb-3 transition-colors duration-200" style={{ color: "#C8A96B" }} />
                  <p className="font-semibold text-sm text-white" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{award}</p>
                  <p className="text-[11px] mt-1" style={{ fontFamily: "'Inter', sans-serif", color: "rgba(255,255,255,0.35)" }}>{detail}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

// ─── SERVICES ─────────────────────────────────────────────────────────────────
const SERVICES_LIST = [
  { Icon: Film, title: "Corporate Films", desc: "Internal comms, brand documentaries, and annual reports — stories that move organisations forward.", img: "1574717024653-61fd2cf4d44d" },
  { Icon: Camera, title: "Commercial Production", desc: "TV, social, and digital commercials crafted to cut through noise and drive lasting recall.", img: "1485846234645-a62644f84728" },
  { Icon: Camera, title: "Product Videos", desc: "Hero reels and demo films that reveal the beauty and function of what you make.", img: "1558618666-fcd25c85cd64" },
  { Icon: Camera, title: "Event Coverage", desc: "Conferences, product launches, and ceremonies captured with broadcast-quality precision.", img: "1560472354-b33ff0c44a43" },
  { Icon: Camera, title: "Drone Cinematography", desc: "Licensed aerial photography for real estate, construction, landscape, and live events.", img: "1508739773434-c26b3d09e071" },
  { Icon: Globe, title: "Website Development", desc: "Custom-coded sites built on Next.js or Webflow with CMS, animations, and full SEO stack.", img: "1531403236541-e5f16c22a4c3" },
  { Icon: Monitor, title: "UI/UX Design", desc: "User research, wireframes, prototypes, and polished UI delivered in Figma and production-ready.", img: "1561070791-2526d30994b5" },
  { Icon: Palette, title: "Graphic Design", desc: "Print collateral, packaging, presentations, and digital assets at production scale and speed.", img: "1561070791-2526d30994b5" },
  { Icon: Layers, title: "Brand Identity", desc: "Complete brand systems: strategy, naming, logo mark, color, typography, and guidelines.", img: "1558618666-fcd25c85cd64" },
];

function ServicesPage({ setPage }: { setPage: (p: string) => void }) {
  return (
    <div className="pt-[76px]">
      <section className="py-28 px-6 lg:px-14 max-w-[1440px] mx-auto">
        <Reveal>
          <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Services</p>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(3rem, 6vw, 5.5rem)", fontWeight: 900, color: "#111", lineHeight: 1.04, letterSpacing: "-0.025em" }} className="mb-6">
            Creative services built<br />for <em style={{ fontStyle: "italic" }}>modern brands.</em>
          </h1>
          <p className="text-[15px] leading-relaxed max-w-xl" style={{ fontFamily: "'Inter', sans-serif", color: "#888" }}>
            From a single hero film to a complete brand overhaul — we bring the same obsessive craft to every engagement, at any scale.
          </p>
        </Reveal>
      </section>

      {/* Services */}
      <section className="pb-32 px-6 lg:px-14 max-w-[1440px] mx-auto">
        <div className="flex flex-col gap-4">
          {SERVICES_LIST.map((s, i) => (
            <Reveal key={i} delay={0.05}>
              <div
                className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center p-6 lg:p-8 rounded-2xl border transition-all duration-300 hover:border-[#C8A96B33] hover:bg-[#FFFDF8] group cursor-pointer"
                style={{ borderColor: "#f0f0f0" }}
                onClick={() => { setPage("ServiceDetail"); window.scrollTo({ top: 0 }); }}
              >
                <div className="lg:col-span-1 flex items-center">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center transition-all duration-300 group-hover:bg-[#C8A96B]" style={{ background: "rgba(200,169,107,0.09)" }}>
                    <s.Icon size={18} className="transition-colors duration-300 group-hover:text-white" style={{ color: "#C8A96B" }} />
                  </div>
                </div>
                <div className="lg:col-span-3">
                  <h3 className="font-bold text-base" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{s.title}</h3>
                </div>
                <div className="lg:col-span-5">
                  <p className="text-[13px] leading-relaxed" style={{ fontFamily: "'Inter', sans-serif", color: "#888" }}>{s.desc}</p>
                </div>
                <div className="lg:col-span-3 flex items-center justify-end gap-3">
                  <button
                    className="flex items-center gap-2 px-5 py-2.5 rounded-full text-[12px] font-semibold transition-all duration-200 hover:scale-105"
                    style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", background: "#111", color: "#fff" }}
                  >
                    View Details <ArrowRight size={11} />
                  </button>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}

// ─── SERVICE DETAIL ───────────────────────────────────────────────────────────
const SERVICE_FAQS = [
  { q: "What is your typical project timeline?", a: "Most corporate films run 4–8 weeks from brief to delivery. Commercials vary from 2–6 weeks. We always discuss and agree on timelines before kickoff." },
  { q: "Do you work with international clients?", a: "Yes — roughly 40% of our clients are based outside the US. We have experience with remote production management and international shoots." },
  { q: "What is included in the deliverables?", a: "All deliverables are specified in the project brief. Typically this includes master files, platform-specific exports, and raw/colour-graded assets as agreed." },
  { q: "Can we be involved during production?", a: "Absolutely. We encourage clients to join key production days and provide feedback at every stage gate through our review portal." },
];

function ServiceDetailPage({ setPage }: { setPage: (p: string) => void }) {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="pt-[76px]">
      {/* Hero banner */}
      <section className="relative h-[60vh] overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=1800&h=800&fit=crop&auto=format"
          alt="Corporate Films"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.2) 60%, transparent 100%)" }} />
        <div className="absolute inset-0 flex items-end">
          <div className="px-6 lg:px-14 pb-16 max-w-[1440px] mx-auto w-full">
            <Reveal>
              <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Service</p>
              <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.5rem, 5vw, 4.5rem)", fontWeight: 900, color: "#fff", lineHeight: 1.06, letterSpacing: "-0.025em" }}>
                Corporate Films
              </h1>
            </Reveal>
          </div>
        </div>
        <button
          onClick={() => { setPage("Services"); window.scrollTo({ top: 0 }); }}
          className="absolute top-24 left-6 lg:left-14 flex items-center gap-2 text-[12px] font-semibold text-white/60 hover:text-white transition-colors"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          <ChevronRight size={14} style={{ transform: "rotate(180deg)" }} /> Back to Services
        </button>
      </section>

      <div className="max-w-[1440px] mx-auto px-6 lg:px-14">
        {/* Overview */}
        <section className="py-24 grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <Reveal>
              <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "2.25rem", fontWeight: 900, color: "#111", lineHeight: 1.1, letterSpacing: "-0.02em" }}>
                Service Overview
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            <Reveal delay={0.15}>
              <p className="text-[15px] leading-[1.9] mb-5" style={{ fontFamily: "'Inter', sans-serif", color: "#666" }}>
                Our corporate film service produces high-impact narrative content for brands that need to communicate internally, externally, or both. We handle everything from brand documentaries and annual reports to onboarding films and executive communications.
              </p>
              <p className="text-[15px] leading-[1.9]" style={{ fontFamily: "'Inter', sans-serif", color: "#666" }}>
                Every film we produce is driven by a clear strategic brief and shaped by cinematography that matches the world-class quality of the brands we represent.
              </p>
              <div className="flex flex-wrap gap-3 mt-8">
                {["Brand Films", "Documentaries", "Annual Reports", "Internal Comms", "Executive Profiles"].map((tag) => (
                  <span key={tag} className="px-4 py-2 rounded-full text-[12px] font-medium" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", background: "#F7F7F7", color: "#666" }}>{tag}</span>
                ))}
              </div>
            </Reveal>
          </div>
        </section>

        {/* Deliverables */}
        <section className="py-16 border-t border-gray-100">
          <Reveal>
            <h3 className="text-xl font-bold mb-10" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>What You Receive</h3>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { Icon: Film, label: "Master File", desc: "4K ProRes master for archival and broadcast use" },
              { Icon: Monitor, label: "Web Exports", desc: "H.264/H.265 versions optimised for web delivery" },
              { Icon: Layers, label: "Social Cuts", desc: "Platform-specific edits for Instagram, LinkedIn & YouTube" },
              { Icon: Palette, label: "Colour Grade", desc: "Full DaVinci Resolve grade with LUT package" },
              { Icon: Camera, label: "RAW Footage", desc: "Optional: full unedited camera originals" },
              { Icon: Globe, label: "Subtitles", desc: "SRT files in up to 3 languages" },
            ].map(({ Icon, label, desc }) => (
              <Reveal key={label}>
                <div className="p-6 rounded-xl" style={{ background: "#F7F7F7" }}>
                  <Check size={15} style={{ color: "#C8A96B", marginBottom: 12 }} />
                  <h4 className="font-semibold text-sm mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{label}</h4>
                  <p className="text-[12px]" style={{ fontFamily: "'Inter', sans-serif", color: "#999" }}>{desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* FAQs */}
        <section className="py-16 border-t border-gray-100 mb-8">
          <Reveal>
            <h3 className="text-xl font-bold mb-10" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>Frequently Asked</h3>
          </Reveal>
          <div className="flex flex-col gap-3 max-w-2xl">
            {SERVICE_FAQS.map((faq, i) => (
              <Reveal key={i} delay={i * 0.07}>
                <div className="rounded-2xl border overflow-hidden transition-all duration-200 hover:border-[#C8A96B44]" style={{ borderColor: "#eee" }}>
                  <button
                    className="w-full flex items-center justify-between px-6 py-5 text-left"
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  >
                    <span className="text-sm font-semibold pr-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{faq.q}</span>
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-200"
                      style={{ background: openFaq === i ? "#C8A96B" : "#F7F7F7" }}
                    >
                      {openFaq === i ? <Minus size={13} className="text-white" /> : <Plus size={13} style={{ color: "#888" }} />}
                    </div>
                  </button>
                  <div
                    className="overflow-hidden transition-all duration-300"
                    style={{ maxHeight: openFaq === i ? "120px" : "0" }}
                  >
                    <p className="px-6 pb-5 text-[13px] leading-relaxed" style={{ fontFamily: "'Inter', sans-serif", color: "#777" }}>{faq.a}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </section>
      </div>

      {/* Contact CTA */}
      <section className="mx-4 lg:mx-14 mb-20 rounded-3xl overflow-hidden" style={{ background: "#111" }}>
        <div className="px-8 lg:px-16 py-16 text-center relative">
          <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 50% 0%, rgba(200,169,107,0.12) 0%, transparent 60%)" }} />
          <Reveal>
            <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(1.75rem, 3vw, 2.5rem)", fontWeight: 900, color: "#fff", lineHeight: 1.1, letterSpacing: "-0.02em" }} className="mb-6">
              Interested in Corporate Films?
            </h3>
            <button
              onClick={() => { setPage("Contact"); window.scrollTo({ top: 0 }); }}
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full text-[13px] font-semibold transition-all duration-300 hover:scale-105"
              style={{ background: "#C8A96B", color: "#fff", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              Start a Conversation <ArrowRight size={13} />
            </button>
          </Reveal>
        </div>
      </section>

      {/* Sticky inquiry */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => { setPage("Contact"); window.scrollTo({ top: 0 }); }}
          className="flex items-center gap-2 px-5 py-3 rounded-full text-[12px] font-semibold shadow-2xl shadow-black/20 transition-all hover:scale-105"
          style={{ background: "#C8A96B", color: "#fff", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          <Mail size={13} /> Get a Quote
        </button>
      </div>
    </div>
  );
}

// ─── WORK ─────────────────────────────────────────────────────────────────────
const ALL_FILTERS = ["All", "Corporate", "Commercial", "Branding", "Digital", "Healthcare", "Technology"];
const ALL_WORK = [
  { title: "Horizon Annual Report Film", cat: "Corporate", client: "Horizon Group", year: "2024", img: "1574717024653-61fd2cf4d44d" },
  { title: "Vetro Launch Campaign", cat: "Commercial", client: "Vetro Wellness", year: "2023", img: "1485846234645-a62644f84728" },
  { title: "Strata Platform Launch", cat: "Digital", client: "Strata Tech", year: "2024", img: "1561070791-2526d30994b5" },
  { title: "Meridian Brand System", cat: "Branding", client: "Meridian Co.", year: "2023", img: "1558618666-fcd25c85cd64" },
  { title: "Pinnacle Executive Series", cat: "Corporate", client: "Pinnacle Finance", year: "2022", img: "1531403236541-e5f16c22a4c3" },
  { title: "Luno Health Campaign", cat: "Healthcare", client: "Luno Health", year: "2024", img: "1560472354-b33ff0c44a43" },
  { title: "Aero Real Estate Reel", cat: "Digital", client: "Aero Properties", year: "2023", img: "1508739773434-c26b3d09e071" },
  { title: "Forge Identity System", cat: "Branding", client: "Forge Studio", year: "2022", img: "1522071820081-009f0129c71c" },
  { title: "Nexus Tech Brand Film", cat: "Technology", client: "Nexus Systems", year: "2024", img: "1534972195531-d236b7a1b55d" },
];

function WorkPage({ setPage }: { setPage: (p: string) => void }) {
  const [active, setActive] = useState("All");
  const filtered = active === "All" ? ALL_WORK : ALL_WORK.filter((w) => w.cat === active);
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <div className="pt-[76px]">
      <section className="py-24 px-6 lg:px-14 max-w-[1440px] mx-auto">
        <Reveal>
          <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Portfolio</p>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(3rem, 6vw, 5.5rem)", fontWeight: 900, color: "#111", lineHeight: 1.04, letterSpacing: "-0.025em" }} className="mb-12">
            A portfolio built<br />on <em style={{ fontStyle: "italic" }}>results.</em>
          </h1>
        </Reveal>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-14">
          {ALL_FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setActive(f)}
              className="px-5 py-2 rounded-full text-[12px] font-semibold transition-all duration-200"
              style={{
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                background: active === f ? "#111" : "#F7F7F7",
                color: active === f ? "#fff" : "#888",
              }}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((w, i) => (
            <div
              key={w.title}
              className="group cursor-pointer"
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
              onClick={() => { setPage("WorkDetail"); window.scrollTo({ top: 0 }); }}
              style={{
                opacity: 0,
                transform: "translateY(30px)",
                animation: "none",
              }}
              ref={(el) => {
                if (!el) return;
                const obs = new IntersectionObserver(([e]) => {
                  if (e.isIntersecting) {
                    el.style.transition = `opacity 0.7s cubic-bezier(0.16,1,0.3,1) ${i * 0.07}s, transform 0.7s cubic-bezier(0.16,1,0.3,1) ${i * 0.07}s`;
                    el.style.opacity = "1";
                    el.style.transform = "none";
                    obs.disconnect();
                  }
                }, { threshold: 0.08 });
                obs.observe(el);
              }}
            >
              <div className="relative overflow-hidden rounded-2xl mb-4" style={{ height: 340, background: "#F3F3F3" }}>
                <img
                  src={`https://images.unsplash.com/photo-${w.img}?w=700&h=500&fit=crop&auto=format`}
                  alt={w.title}
                  className="w-full h-full object-cover transition-transform duration-600 ease-out"
                  style={{ transform: hovered === i ? "scale(1.06)" : "scale(1)" }}
                />
                <div
                  className="absolute inset-0 transition-opacity duration-400"
                  style={{ background: "rgba(0,0,0,0.38)", opacity: hovered === i ? 1 : 0 }}
                />
                <div
                  className="absolute inset-0 flex items-center justify-center transition-all duration-300"
                  style={{ opacity: hovered === i ? 1 : 0 }}
                >
                  <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.25)", backdropFilter: "blur(12px)" }}>
                    <ArrowUpRight size={18} className="text-white" />
                  </div>
                </div>
              </div>
              <div className="flex items-start justify-between px-1">
                <div>
                  <h3 className="font-semibold text-[14px]" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{w.title}</h3>
                  <p className="text-[12px] mt-1" style={{ fontFamily: "'Inter', sans-serif", color: "#bbb" }}>{w.client} · {w.year}</p>
                </div>
                <span className="text-[11px] px-3 py-1 rounded-full mt-0.5" style={{ fontFamily: "'Inter', sans-serif", background: "#F7F7F7", color: "#999" }}>{w.cat}</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

// ─── WORK DETAIL ──────────────────────────────────────────────────────────────
function WorkDetailPage({ setPage }: { setPage: (p: string) => void }) {
  return (
    <div className="pt-[76px]">
      {/* Hero */}
      <section className="relative h-[75vh] overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=1800&h=900&fit=crop&auto=format"
          alt="Horizon Corporate Film"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.88) 0%, transparent 55%)" }} />
        <button
          onClick={() => { setPage("Work"); window.scrollTo({ top: 0 }); }}
          className="absolute top-24 left-6 lg:left-14 flex items-center gap-2 text-[12px] font-semibold text-white/60 hover:text-white transition-colors"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          <ChevronRight size={14} style={{ transform: "rotate(180deg)" }} /> All Projects
        </button>
        <div className="absolute bottom-0 left-0 right-0 px-6 lg:px-14 pb-16 max-w-[1440px] mx-auto">
          <Reveal>
            <div className="flex items-center gap-3 mb-4">
              <span className="text-[10px] font-bold uppercase tracking-[0.15em] px-3 py-1.5 rounded-full" style={{ background: "#C8A96B", color: "#fff", fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Corporate Film</span>
              <span className="text-[12px]" style={{ fontFamily: "'Inter', sans-serif", color: "rgba(255,255,255,0.45)" }}>2024</span>
            </div>
            <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.5rem, 5vw, 4.5rem)", fontWeight: 900, color: "#fff", lineHeight: 1.06, letterSpacing: "-0.025em" }}>
              Horizon Annual Report Film
            </h1>
            <p className="mt-3 text-[14px]" style={{ fontFamily: "'Inter', sans-serif", color: "rgba(255,255,255,0.5)" }}>Client: Horizon Group</p>
          </Reveal>
        </div>
      </section>

      <div className="max-w-[1440px] mx-auto px-6 lg:px-14">
        {/* Meta row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5 py-12 border-b border-gray-100">
          {[
            { label: "Deliverable", value: "12-min Brand Film" },
            { label: "Timeline", value: "6 Weeks" },
            { label: "Team", value: "8 Creatives" },
            { label: "Budget Range", value: "$80,000–$120,000" },
          ].map(({ label, value }) => (
            <div key={label}>
              <p className="text-[10px] font-bold uppercase tracking-[0.12em] mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>{label}</p>
              <p className="text-sm font-semibold" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{value}</p>
            </div>
          ))}
        </div>

        {/* Overview / Challenge / Solution */}
        {[
          { heading: "The Brief", body: "Horizon Group needed a flagship annual report film that would be screened at their global shareholder meeting and distributed to 18,000+ employees. The film needed to communicate a year of transformation — a new CEO, three acquisitions, and a pivot to sustainable finance — without feeling like a corporate checklist." },
          { heading: "The Challenge", body: "Annual report films are notoriously dull. The brief gave us extensive data and a dense narrative to condense into 12 minutes without losing the emotional thread. We also had a tight 6-week window from brief to premiere, with shoots across four cities on three continents." },
          { heading: "Our Solution", body: "We structured the film as a personal essay narrated by the incoming CEO — intimate, honest, and cinematic. Six days of principal photography across New York, London, Singapore, and Nairobi gave the film real global texture. The grade was inspired by archival documentary, giving a sense of weight and permanence to what was ultimately a year of transition." },
        ].map(({ heading, body }) => (
          <section key={heading} className="py-16 border-b border-gray-100 grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-4">
              <Reveal>
                <h2 className="text-xl font-bold" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{heading}</h2>
              </Reveal>
            </div>
            <div className="lg:col-span-7 lg:col-start-6">
              <Reveal delay={0.1}>
                <p className="text-[15px] leading-[1.9]" style={{ fontFamily: "'Inter', sans-serif", color: "#666" }}>{body}</p>
              </Reveal>
            </div>
          </section>
        ))}

        {/* Results */}
        <section className="py-20 border-b border-gray-100">
          <Reveal>
            <h2 className="text-xl font-bold mb-12" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>Results</h2>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[
              { Icon: Eye, stat: "2.4M", label: "Film views in 30 days" },
              { Icon: TrendingUp, stat: "+34%", label: "Employee engagement score" },
              { Icon: Award, stat: "3", label: "Industry awards received" },
            ].map(({ Icon, stat, label }) => (
              <Reveal key={label}>
                <div className="p-8 rounded-2xl text-center" style={{ background: "#F7F7F7" }}>
                  <Icon size={22} style={{ color: "#C8A96B", margin: "0 auto 16px" }} />
                  <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "2.5rem", fontWeight: 900, color: "#111" }}>{stat}</div>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.8rem", color: "#aaa", marginTop: 6 }}>{label}</div>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* Gallery */}
        <section className="py-20">
          <Reveal>
            <h2 className="text-xl font-bold mb-10" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>Gallery</h2>
          </Reveal>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { img: "1485846234645-a62644f84728", h: 280 },
              { img: "1522071820081-009f0129c71c", h: 360 },
              { img: "1531403236541-e5f16c22a4c3", h: 360 },
              { img: "1560472354-b33ff0c44a43", h: 280 },
              { img: "1508739773434-c26b3d09e071", h: 280 },
              { img: "1558618666-fcd25c85cd64", h: 360 },
            ].map((item, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className="relative overflow-hidden rounded-2xl group" style={{ height: item.h, background: "#F3F3F3" }}>
                  <img
                    src={`https://images.unsplash.com/photo-${item.img}?w=600&h=500&fit=crop&auto=format`}
                    alt="Production still"
                    className="w-full h-full object-cover transition-transform duration-600 group-hover:scale-105"
                  />
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* Client feedback */}
        <section className="py-16 border-t border-gray-100">
          <Reveal>
            <blockquote className="max-w-2xl">
              <div className="flex gap-0.5 mb-6">
                {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="#C8A96B" style={{ color: "#C8A96B" }} />)}
              </div>
              <p style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(1.25rem, 2vw, 1.75rem)", fontStyle: "italic", color: "#111", lineHeight: 1.5, fontWeight: 700 }}>
                &ldquo;The film premiered to a standing ovation at our shareholder meeting. Lumière captured a year of transformation in a way we never could have articulated ourselves.&rdquo;
              </p>
              <div className="flex items-center gap-3 mt-8">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&auto=format"
                  alt="Marcus Chen"
                  className="w-11 h-11 rounded-full object-cover bg-gray-200"
                />
                <div>
                  <p className="font-semibold text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>Marcus Chen</p>
                  <p className="text-[12px]" style={{ fontFamily: "'Inter', sans-serif", color: "#bbb" }}>CMO, Horizon Group</p>
                </div>
              </div>
            </blockquote>
          </Reveal>
        </section>

        {/* Next project */}
        <section className="py-16 border-t border-gray-100 mb-8">
          <Reveal>
            <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-6" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Next Project</p>
            <div
              className="group relative overflow-hidden rounded-2xl cursor-pointer"
              style={{ height: 280, background: "#F3F3F3" }}
              onClick={() => { setPage("Work"); window.scrollTo({ top: 0 }); }}
            >
              <img
                src="https://images.unsplash.com/photo-1485846234645-a62644f84728?w=1400&h=400&fit=crop&auto=format"
                alt="Vetro Campaign"
                className="w-full h-full object-cover transition-transform duration-600 group-hover:scale-104"
              />
              <div className="absolute inset-0" style={{ background: "linear-gradient(to right, rgba(0,0,0,0.7) 0%, transparent 60%)" }} />
              <div className="absolute inset-0 flex items-center px-10">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: "#C8A96B", fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Commercial</span>
                  <h3 className="mt-1.5 text-2xl font-bold text-white" style={{ fontFamily: "'Playfair Display', serif" }}>Vetro Launch Campaign</h3>
                </div>
              </div>
              <div className="absolute right-8 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.2)" }}>
                <ArrowRight size={18} className="text-white" />
              </div>
            </div>
          </Reveal>
        </section>
      </div>
    </div>
  );
}

// ─── CAREERS ──────────────────────────────────────────────────────────────────
const OPEN_ROLES = [
  { title: "Senior Cinematographer", dept: "Video Production", type: "Full-time", loc: "Los Angeles, CA" },
  { title: "Brand Designer", dept: "Design", type: "Full-time", loc: "Remote" },
  { title: "Frontend Developer", dept: "Development", type: "Full-time", loc: "Los Angeles, CA" },
  { title: "Social Media Producer", dept: "Marketing", type: "Contract", loc: "Remote" },
  { title: "Motion Graphics Artist", dept: "Video Production", type: "Full-time", loc: "Los Angeles, CA" },
  { title: "UX Researcher", dept: "Design", type: "Part-time", loc: "Remote" },
];

const DEPT_FILTERS = ["All", "Design", "Video Production", "Development", "Marketing"];

function CareersPage({ setPage }: { setPage: (p: string) => void }) {
  const [dept, setDept] = useState("All");
  const filtered = dept === "All" ? OPEN_ROLES : OPEN_ROLES.filter((j) => j.dept === dept);

  return (
    <div className="pt-[76px]">
      {/* Hero */}
      <section className="py-28 px-6 lg:px-14 max-w-[1440px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div>
          <Reveal>
            <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Careers</p>
            <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(3rem, 5vw, 4.75rem)", fontWeight: 900, color: "#111", lineHeight: 1.06, letterSpacing: "-0.025em" }}>
              Join a team that<br /><em style={{ fontStyle: "italic" }}>loves creating.</em>
            </h1>
            <p className="mt-7 text-[15px] leading-[1.8] max-w-md" style={{ fontFamily: "'Inter', sans-serif", color: "#888" }}>
              We&apos;re a studio of makers, thinkers, and storytellers. If you obsess over craft and believe great work changes culture, you&apos;ll feel at home.
            </p>
          </Reveal>
        </div>
        <Reveal delay={0.15}>
          <div className="relative rounded-2xl overflow-hidden" style={{ height: 440, background: "#F7F7F7" }}>
            <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=700&fit=crop&auto=format" alt="Studio culture" className="w-full h-full object-cover" />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.4) 0%, transparent 50%)" }} />
            <div className="absolute bottom-6 left-6">
              <span className="text-[11px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-full" style={{ background: "#C8A96B", color: "#fff", fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                24 Creatives & Counting
              </span>
            </div>
          </div>
        </Reveal>
      </section>

      {/* Benefits */}
      <section style={{ background: "#F7F7F7" }} className="py-20 px-6 lg:px-14">
        <div className="max-w-[1440px] mx-auto">
          <Reveal><h2 className="text-2xl font-bold mb-10" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>Why Lumière</h2></Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { Icon: Camera, title: "Cinema-grade tools", body: "Work with ARRI Alexa, Sony VENICE, and state-of-the-art post suites." },
              { Icon: Globe, title: "Remote-friendly", body: "Flexible remote options for most roles, with our beautiful LA studio as home base." },
              { Icon: TrendingUp, title: "Growth-first culture", body: "Dedicated $3K learning budget, mentorship, and transparent paths to leadership." },
              { Icon: Zap, title: "Competitive pay", body: "Market-leading salaries, equity options, and comprehensive health benefits." },
              { Icon: Users, title: "Creative autonomy", body: "We hire experts and trust their judgment. Your ideas shape the final work." },
              { Icon: Star, title: "Meaningful clients", body: "Partner with brands that value excellence and give you space to do great things." },
            ].map(({ Icon, title, body }) => (
              <Reveal key={title}>
                <div className="bg-white p-8 rounded-2xl">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-5" style={{ background: "rgba(200,169,107,0.1)" }}>
                    <Icon size={17} style={{ color: "#C8A96B" }} />
                  </div>
                  <h4 className="font-semibold text-sm mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{title}</h4>
                  <p className="text-[13px] leading-relaxed" style={{ fontFamily: "'Inter', sans-serif", color: "#888" }}>{body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Open roles */}
      <section className="py-28 px-6 lg:px-14 max-w-[1440px] mx-auto">
        <Reveal>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "2.5rem", fontWeight: 900, color: "#111", letterSpacing: "-0.02em" }} className="mb-8">
            Open Positions
          </h2>
        </Reveal>
        <div className="flex flex-wrap gap-2 mb-10">
          {DEPT_FILTERS.map((f) => (
            <button key={f} onClick={() => setDept(f)} className="px-4 py-2 rounded-full text-[12px] font-semibold transition-all duration-200" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", background: dept === f ? "#111" : "#F7F7F7", color: dept === f ? "#fff" : "#888" }}>
              {f}
            </button>
          ))}
        </div>
        <div className="flex flex-col gap-3">
          {filtered.map((job, i) => (
            <Reveal key={i} delay={i * 0.07}>
              <div
                className="flex flex-col md:flex-row items-start md:items-center justify-between p-6 rounded-2xl border transition-all duration-250 hover:border-[#C8A96B33] hover:bg-[#FFFDF8] cursor-pointer group"
                style={{ borderColor: "#EBEBEB" }}
                onClick={() => { setPage("JobDetail"); window.scrollTo({ top: 0 }); }}
              >
                <div>
                  <h4 className="font-semibold text-[15px]" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{job.title}</h4>
                  <div className="flex items-center gap-3 mt-1.5">
                    <span className="text-[12px]" style={{ fontFamily: "'Inter', sans-serif", color: "#bbb" }}>{job.dept}</span>
                    <span className="w-1 h-1 rounded-full bg-gray-300" />
                    <span className="text-[12px]" style={{ fontFamily: "'Inter', sans-serif", color: "#bbb" }}>{job.loc}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3 mt-4 md:mt-0">
                  <span className="px-3 py-1 rounded-full text-[11px]" style={{ fontFamily: "'Inter', sans-serif", background: "#F7F7F7", color: "#999" }}>{job.type}</span>
                  <button className="flex items-center gap-1.5 px-4 py-2 rounded-full text-[12px] font-semibold transition-all" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", background: "#111", color: "#fff" }}>
                    Apply <ArrowRight size={11} />
                  </button>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}

// ─── JOB DETAIL ───────────────────────────────────────────────────────────────
function JobDetailPage({ setPage }: { setPage: (p: string) => void }) {
  const [submitted, setSubmitted] = useState(false);

  return (
    <div className="pt-[76px]">
      <div className="max-w-[860px] mx-auto px-6 lg:px-12 py-20">
        <button onClick={() => { setPage("Careers"); window.scrollTo({ top: 0 }); }} className="flex items-center gap-2 text-[12px] font-semibold mb-14 hover:gap-3 transition-all" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#aaa" }}>
          <ChevronRight size={13} style={{ transform: "rotate(180deg)" }} /> Back to Careers
        </button>

        <Reveal>
          <div className="flex items-center gap-3 mb-3">
            <span className="px-3 py-1.5 rounded-full text-[11px] font-semibold" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", background: "rgba(200,169,107,0.12)", color: "#C8A96B" }}>Video Production</span>
            <span className="text-[12px]" style={{ fontFamily: "'Inter', sans-serif", color: "#bbb" }}>Full-time · Los Angeles, CA</span>
          </div>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: 900, color: "#111", lineHeight: 1.1, letterSpacing: "-0.02em" }} className="mb-14">
            Senior Cinematographer
          </h1>
        </Reveal>

        {[
          {
            heading: "About the Role",
            body: "We are looking for a Senior Cinematographer to lead visual storytelling across our client film productions. You will collaborate directly with our Creative Director from concept through post-production, helping shape the visual language of some of the world&apos;s most ambitious brand films.",
          },
          {
            heading: "Responsibilities",
            items: [
              "Lead camera operation and lighting design across all productions",
              "Collaborate with directors and clients to realise the creative vision",
              "Supervise and mentor junior camera operators and focus pullers",
              "Manage equipment selection, rental, and maintenance budgets",
              "Contribute to pre-production creative development and storyboarding",
            ],
          },
          {
            heading: "Requirements",
            items: [
              "5+ years experience in narrative or commercial cinematography",
              "Proficiency with ARRI Alexa, Sony VENICE, and RED cinema cameras",
              "Deep working knowledge of lighting for studio and location",
              "Strong reel demonstrating clear, distinctive visual language",
              "Excellent communication and creative leadership skills",
            ],
          },
          {
            heading: "Benefits",
            items: [
              "Salary range: $120,000 – $160,000 depending on experience",
              "Full medical, dental, and vision coverage",
              "$3,000 annual learning and equipment budget",
              "Flexible PTO plus 2-week mandatory studio closure",
              "Access to our LA studio, screening room, and full camera house",
            ],
          },
        ].map((section, si) => (
          <Reveal key={section.heading} delay={si * 0.1}>
            <div className="mb-12 pb-12 border-b border-gray-100 last:border-0 last:mb-0 last:pb-0">
              <h3 className="text-lg font-bold mb-5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>{section.heading}</h3>
              {section.body ? (
                <p className="text-[15px] leading-[1.9]" style={{ fontFamily: "'Inter', sans-serif", color: "#666" }} dangerouslySetInnerHTML={{ __html: section.body }} />
              ) : (
                <ul className="flex flex-col gap-3.5">
                  {section.items?.map((item) => (
                    <li key={item} className="flex items-start gap-3 text-[14px]" style={{ fontFamily: "'Inter', sans-serif", color: "#666", lineHeight: 1.6 }}>
                      <Check size={14} style={{ color: "#C8A96B", marginTop: 4, flexShrink: 0 }} />
                      {item}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </Reveal>
        ))}

        {/* Application form */}
        <Reveal>
          <div className="mt-4 p-8 rounded-2xl" style={{ background: "#F7F7F7" }}>
            <h3 className="text-lg font-bold mb-7" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#111" }}>
              {submitted ? "Application Received" : "Apply for this Role"}
            </h3>
            {submitted ? (
              <div className="text-center py-8">
                <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-5" style={{ background: "rgba(200,169,107,0.12)" }}>
                  <Check size={22} style={{ color: "#C8A96B" }} />
                </div>
                <p className="text-sm" style={{ fontFamily: "'Inter', sans-serif", color: "#888" }}>We&apos;ll review your application and be in touch within 5 business days.</p>
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }} className="flex flex-col gap-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {["Full Name", "Email Address"].map((f) => (
                    <div key={f}>
                      <label className="text-[10px] font-bold uppercase tracking-[0.12em] block mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#bbb" }}>{f}</label>
                      <input required placeholder={f} className="w-full px-4 py-3.5 rounded-xl text-[13px] border border-gray-200 bg-white outline-none focus:border-[#C8A96B] transition-colors" style={{ fontFamily: "'Inter', sans-serif", color: "#111" }} />
                    </div>
                  ))}
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-[0.12em] block mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#bbb" }}>Portfolio / Showreel URL</label>
                  <input placeholder="https://" className="w-full px-4 py-3.5 rounded-xl text-[13px] border border-gray-200 bg-white outline-none focus:border-[#C8A96B] transition-colors" style={{ fontFamily: "'Inter', sans-serif", color: "#111" }} />
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-[0.12em] block mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#bbb" }}>Why Lumière?</label>
                  <textarea required rows={4} placeholder="Tell us what draws you to this role and studio..." className="w-full px-4 py-3.5 rounded-xl text-[13px] border border-gray-200 bg-white outline-none focus:border-[#C8A96B] transition-colors resize-none" style={{ fontFamily: "'Inter', sans-serif", color: "#111" }} />
                </div>
                <button type="submit" className="px-7 py-3.5 rounded-full text-[13px] font-semibold transition-all hover:scale-[1.01] hover:shadow-lg" style={{ background: "#111", color: "#fff", fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  Submit Application
                </button>
              </form>
            )}
          </div>
        </Reveal>
      </div>

      {/* Sticky apply */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => document.querySelector("form")?.scrollIntoView({ behavior: "smooth" })}
          className="flex items-center gap-2 px-5 py-3 rounded-full text-[12px] font-semibold shadow-2xl shadow-black/15 transition-all hover:scale-105"
          style={{ background: "#C8A96B", color: "#fff", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          Apply Now <ArrowRight size={13} />
        </button>
      </div>
    </div>
  );
}

// ─── CONTACT ──────────────────────────────────────────────────────────────────
function ContactPage() {
  const [sent, setSent] = useState(false);

  return (
    <div className="pt-[76px] min-h-screen">
      <section className="py-24 px-6 lg:px-14 max-w-[1440px] mx-auto">
        <Reveal>
          <p className="text-[11px] font-bold uppercase tracking-[0.15em] mb-5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>Get In Touch</p>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(3rem, 6vw, 5.5rem)", fontWeight: 900, color: "#111", lineHeight: 1.04, letterSpacing: "-0.025em" }} className="mb-20">
            Start a<br /><em style={{ fontStyle: "italic" }}>conversation.</em>
          </h1>
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          {/* Left info */}
          <div className="lg:col-span-4">
            <Reveal>
              <div className="flex flex-col gap-8 mb-10">
                {[
                  { Icon: Mail, label: "Email", value: "hello@lumierestudio.co" },
                  { Icon: Phone, label: "Phone", value: "+1 (310) 555-0192" },
                  { Icon: MapPin, label: "Studio Address", value: "8440 Sunset Blvd\nLos Angeles, CA 90069" },
                  { Icon: Clock, label: "Studio Hours", value: "Mon–Fri, 9am–7pm PST" },
                ].map(({ Icon, label, value }) => (
                  <div key={label} className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "rgba(200,169,107,0.1)", border: "1px solid rgba(200,169,107,0.2)" }}>
                      <Icon size={16} style={{ color: "#C8A96B" }} />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-[0.12em] mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#C8A96B" }}>{label}</p>
                      <p className="text-[13px] whitespace-pre-line" style={{ fontFamily: "'Inter', sans-serif", color: "#555", lineHeight: 1.6 }}>{value}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Map placeholder */}
              <div className="relative overflow-hidden rounded-2xl" style={{ height: 220, background: "#F0EEE8" }}>
                <img
                  src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&h=350&fit=crop&auto=format"
                  alt="Our Los Angeles studio"
                  className="w-full h-full object-cover opacity-80"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin size={24} style={{ color: "#C8A96B", margin: "0 auto 6px" }} />
                    <span className="text-[11px] font-semibold" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#fff" }}>Sunset Blvd, LA</span>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>

          {/* Right form */}
          <div className="lg:col-span-7 lg:col-start-6">
            <Reveal delay={0.15}>
              {sent ? (
                <div className="flex flex-col items-center justify-center py-24 text-center">
                  <div className="w-16 h-16 rounded-full flex items-center justify-center mb-6" style={{ background: "rgba(200,169,107,0.1)" }}>
                    <Check size={24} style={{ color: "#C8A96B" }} />
                  </div>
                  <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: "2rem", fontWeight: 900, color: "#111" }}>Message received.</h3>
                  <p className="mt-3 text-[13px]" style={{ fontFamily: "'Inter', sans-serif", color: "#aaa" }}>We&apos;ll be in touch within 24 hours.</p>
                </div>
              ) : (
                <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="flex flex-col gap-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {["Full Name", "Company"].map((f) => (
                      <div key={f}>
                        <label className="text-[10px] font-bold uppercase tracking-[0.12em] block mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#bbb" }}>{f}</label>
                        <input required placeholder={f} className="w-full px-5 py-4 rounded-xl text-[13px] border border-gray-200 bg-[#FAFAFA] outline-none focus:border-[#C8A96B] transition-colors" style={{ fontFamily: "'Inter', sans-serif", color: "#111" }} />
                      </div>
                    ))}
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-[0.12em] block mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#bbb" }}>Service</label>
                    <select required className="w-full px-5 py-4 rounded-xl text-[13px] border border-gray-200 bg-[#FAFAFA] outline-none focus:border-[#C8A96B] transition-colors" style={{ fontFamily: "'Inter', sans-serif", color: "#555" }}>
                      <option value="">Select a service</option>
                      {["Corporate Film", "Commercial Shoot", "Product Video", "Website Development", "UI/UX Design", "Graphic Design", "Brand Identity", "Social Media Content"].map((s) => <option key={s}>{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-[0.12em] block mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#bbb" }}>Budget Range</label>
                    <select className="w-full px-5 py-4 rounded-xl text-[13px] border border-gray-200 bg-[#FAFAFA] outline-none focus:border-[#C8A96B] transition-colors" style={{ fontFamily: "'Inter', sans-serif", color: "#555" }}>
                      <option value="">Select a range</option>
                      {["Under $5,000", "$5,000 – $15,000", "$15,000 – $50,000", "$50,000 – $150,000", "$150,000+"].map((b) => <option key={b}>{b}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-[0.12em] block mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#bbb" }}>Project Details</label>
                    <textarea
                      required rows={6}
                      placeholder="Describe your project, timeline, and any specific requirements or goals..."
                      className="w-full px-5 py-4 rounded-xl text-[13px] border border-gray-200 bg-[#FAFAFA] outline-none focus:border-[#C8A96B] transition-colors resize-none"
                      style={{ fontFamily: "'Inter', sans-serif", color: "#111" }}
                    />
                  </div>
                  <button
                    type="submit"
                    className="group w-full py-4 rounded-full text-[13px] font-semibold transition-all hover:scale-[1.01] hover:shadow-xl flex items-center justify-center gap-2"
                    style={{ background: "#111", color: "#fff", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                  >
                    Send Message
                    <ArrowRight size={13} className="transition-transform duration-200 group-hover:translate-x-0.5" />
                  </button>
                  <p className="text-center text-[11px]" style={{ fontFamily: "'Inter', sans-serif", color: "#ccc" }}>
                    We respond to all enquiries within 24 hours, Mon–Fri.
                  </p>
                </form>
              )}
            </Reveal>
          </div>
        </div>
      </section>
    </div>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("Home");

  const setPageAndScroll = useCallback((p: string) => {
    setPage(p);
    setTimeout(() => window.scrollTo({ top: 0, behavior: "instant" }), 0);
  }, []);

  const renderPage = () => {
    switch (page) {
      case "Home": return <HomePage setPage={setPageAndScroll} />;
      case "About": return <AboutPage setPage={setPageAndScroll} />;
      case "Services": return <ServicesPage setPage={setPageAndScroll} />;
      case "ServiceDetail": return <ServiceDetailPage setPage={setPageAndScroll} />;
      case "Work": return <WorkPage setPage={setPageAndScroll} />;
      case "WorkDetail": return <WorkDetailPage setPage={setPageAndScroll} />;
      case "Careers": return <CareersPage setPage={setPageAndScroll} />;
      case "JobDetail": return <JobDetailPage setPage={setPageAndScroll} />;
      case "Contact": return <ContactPage />;
      default: return <HomePage setPage={setPageAndScroll} />;
    }
  };

  return (
    <div style={{ fontFamily: "'Inter', sans-serif", background: "#fff", overflowX: "hidden" }}>
      <Nav page={page} setPage={setPageAndScroll} />
      <main style={{ minHeight: "100vh" }}>
        {renderPage()}
      </main>
      <Footer setPage={setPageAndScroll} />
    </div>
  );
}
